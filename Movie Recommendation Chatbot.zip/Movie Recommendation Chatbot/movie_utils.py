import requests
from config import OMDB_API_KEY, OMDB_API_URL


def fetch_movie_recommendations(genre=None, actor=None):
    """
    Fetch movie recommendations based on genre or actor.
    """
    recommendations = []
    search_term = genre if genre else actor  # Determine search term

    if not search_term:
        return {"error": "Please provide either a genre or an actor for the search."}

    # Fetch recommendations from OMDb
    for page in range(1, 3):  # Iterate over the first 2 pages
        params = {
            "apikey": OMDB_API_KEY,
            "s": search_term,
            "type": "movie",
            "page": page
        }
        try:
            response = requests.get(OMDB_API_URL, params=params)
            response.raise_for_status()

            # Extract movie data from response
            movies = response.json().get("Search", [])
            if not movies:
                continue

            # Fetch detailed information for each movie
            for movie in movies:
                try:
                    details_response = requests.get(OMDB_API_URL, params={
                        "apikey": OMDB_API_KEY,
                        "i": movie["imdbID"]
                    })
                    details_response.raise_for_status()
                    details = details_response.json()

                    recommendations.append({
                        "title": details.get("Title"),
                        "release_date": details.get("Released"),
                        "genre": details.get("Genre"),
                        "actors": details.get("Actors"),
                        "rating": details.get("imdbRating"),
                        "plot": details.get("Plot"),
                        "poster": details.get("Poster"),  # Use poster from OMDb API
                    })

                    # Limit the number of recommendations to 5
                    if len(recommendations) >= 10:
                        break

                except requests.exceptions.RequestException as e:
                    print(f"Error fetching movie details: {e}")
                    continue  # Skip to the next movie if an error occurs

            if len(recommendations) >= 20:
                break  # Stop fetching once we have 5 recommendations

        except requests.exceptions.RequestException as e:
            print(f"Error fetching search results: {e}")
            continue  # Skip to the next page if an error occurs

    return recommendations if recommendations else {"message": "No recommendations found."}
