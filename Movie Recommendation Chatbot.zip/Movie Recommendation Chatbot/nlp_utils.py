import spacy
from fuzzywuzzy import process
from fuzzywuzzy import fuzz
import requests
from config import OMDB_API_KEY  # Import the API key securely from config.py

# Load the spaCy model
nlp = spacy.load("en_core_web_sm")

# Predefined list of genres and a placeholder for common actors
genres = [
    "action", "animation", "comedy", "crime", "drama", "experimental",
    "fantasy", "historical", "horror", "romance", "science fiction",
    "thriller", "western", "musical", "war"
]

common_actors = [
    "Chris Pratt", "Zoe Saldana", "Dave Bautista", "Leonardo DiCaprio",
    "Robert Downey Jr.", "Scarlett Johansson", "Tom Hanks", "Emma Stone"
]

OMDB_API_URL = "http://www.omdbapi.com/"


def extract_entities(user_input):
    """
    Extract genre and actor entities from user input with fuzzy matching for actor names.
    """
    doc = nlp(user_input)
    genre = None
    actor = None

    # Extract genre
    for token in doc:
        if token.text.lower() in genres:
            genre = token.text.capitalize()

    # Find actor using fuzzy matching
    extracted_actor = None
    for name in common_actors:
        if name.lower() in user_input.lower():
            extracted_actor = name
            break

    if not extracted_actor:
        # Perform fuzzy matching to suggest the closest match
        user_input_lower = user_input.lower()
        suggested_actor, similarity = process.extractOne(
            user_input_lower, common_actors, scorer=lambda s1, s2: fuzz.partial_ratio(s1.lower(), s2.lower())
        )
        if similarity > 60:  # Threshold for similarity
            extracted_actor = suggested_actor

    return genre, extracted_actor


def fetch_detailed_movie_data(user_input, max_movies=5):
    """
    Fetch movie recommendations based on extracted genre or actor.
    """
    genre, actor = extract_entities(user_input)

    # Decide the search term based on extracted entities
    if actor:
        search_term = actor
    elif genre:
        search_term = genre
    else:
        search_term = user_input  # Fallback to user input if no genre/actor found

    recommendations = []
    for page in range(1, 3):  # Iterate over the first 2 pages of search results
        movies = search_movies(search_term, page)
        if not movies:
            break
        for movie in movies:
            imdb_id = movie["imdbID"]
            details = get_movie_details(imdb_id)
            recommendations.append({
                "Title": details.get("Title"),
                "Year": details.get("Year"),
                "Director": details.get("Director"),
                "Actors": details.get("Actors"),
                "Genre": details.get("Genre"),
                "Plot": details.get("Plot"),
                "Runtime": details.get("Runtime"),
                "Language": details.get("Language"),
                "Country": details.get("Country"),
                "Ratings": details.get("Ratings"),
                "Poster": details.get("Poster"),
                "BoxOffice": details.get("BoxOffice"),
                "Awards": details.get("Awards")
            })
            if len(recommendations) >= max_movies:
                return recommendations
    return recommendations


def search_movies(search_term, page=1):
    """
    Search movies by a search term using the OMDB API.
    """
    params = {
        "apikey": OMDB_API_KEY,
        "s": search_term,
        "type": "movie",
        "page": page
    }
    response = requests.get(OMDB_API_URL, params=params)
    response.raise_for_status()
    return response.json().get("Search", [])


def get_movie_details(imdb_id):
    """
    Fetch detailed movie data using an IMDb ID.
    """
    params = {
        "apikey": OMDB_API_KEY,
        "i": imdb_id
    }
    response = requests.get(OMDB_API_URL, params=params)
    response.raise_for_status()
    return response.json()


def process_movie_query(user_input):
    """
    Process a user query to extract movie-related details and fetch movie recommendations.
    """
    # Use NLP to extract movie name or related entities
    recommendations = fetch_detailed_movie_data(user_input, max_movies=3)
    return recommendations


# Example usage
if __name__ == "__main__":
    user_query = input("Enter your movie query (e.g., 'Tell me about Avengers or action movies'): ")
    movie_recommendations = process_movie_query(user_query)
    if movie_recommendations:
        for movie in movie_recommendations:
            print(f"Title: {movie['Title']}\nYear: {movie['Year']}\nPlot: {movie['Plot']}\n")
    else:
        print("No movie recommendations found.")
