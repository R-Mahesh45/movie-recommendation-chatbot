from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import requests
from config import OMDB_API_KEY, OMDB_API_URL
from nlp_utils import extract_entities  # Ensure this function is implemented

app = FastAPI()

# Serve static files (HTML, CSS, JS) from the "static" folder
app.mount("/static", StaticFiles(directory="static"), name="static")

# Pydantic models for input validation
class UserQuery(BaseModel):
    query: str

class RecommendationQuery(BaseModel):
    user_input: str

# Helper functions for movie search and recommendations
def search_movies(search_term, page=1):
    """
    Search for movies based on a search term.
    """
    params = {
        "apikey": OMDB_API_KEY,
        "s": search_term,
        "type": "movie",
        "page": page
    }
    try:
        response = requests.get(OMDB_API_URL, params=params)
        response.raise_for_status()
        return response.json().get("Search", [])
    except requests.exceptions.RequestException as e:
        print(f"Error searching for movies: {e}")
        return []

def get_movie_details(imdb_id):
    """
    Fetch detailed information about a specific movie by IMDb ID.
    """
    params = {
        "apikey": OMDB_API_KEY,
        "i": imdb_id
    }
    try:
        response = requests.get(OMDB_API_URL, params=params)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error fetching movie details: {e}")
        return {}

def fetch_detailed_movie_data(search_term, max_movies=5):
    """
    Fetch detailed movie data for a given search term.
    """
    recommendations = []
    for page in range(1, 3):  # Iterate over the first 2 pages of search results
        movies = search_movies(search_term, page)
        if not movies:
            break
        for movie in movies:
            imdb_id = movie["imdbID"]
            details = get_movie_details(imdb_id)
            if details:
                recommendations.append({
                    "Title": details.get("Title"),
                    "Year": details.get("Year"),
                    "Director": details.get("Director"),
                    "Actors": details.get("Actors"),
                    "Genre": details.get("Genre"),
                    "Plot": details.get("Plot"),
                    "Runtime": details.get("Runtime"),
                    "Language": details.get("Language"),
                    "Country": details.get("Country"),
                    "Ratings": details.get("Ratings"),
                    "Poster": details.get("Poster"),
                    "BoxOffice": details.get("BoxOffice"),
                    "Awards": details.get("Awards")
                })
            if len(recommendations) >= max_movies:
                return recommendations
    return recommendations

def fetch_movie_recommendations(genre=None, actor=None):
    """
    Fetch movie recommendations based on genre or actor.
    """
    recommendations = []
    search_term = genre if genre else actor  # Determine search term

    if not search_term:
        return {"error": "Please provide either a genre or an actor for the search."}

    for page in range(1, 3):  # Iterate over the first 2 pages
        movies = search_movies(search_term, page)
        if not movies:
            continue
        for movie in movies:
            imdb_id = movie["imdbID"]
            details = get_movie_details(imdb_id)
            if details:
                recommendations.append({
                    "title": details.get("Title"),
                    "release_date": details.get("Released"),
                    "genre": details.get("Genre"),
                    "actors": details.get("Actors"),
                    "rating": details.get("imdbRating"),
                    "plot": details.get("Plot"),
                    "poster": details.get("Poster")
                })
                if len(recommendations) >= 10:
                    break
        if len(recommendations) >= 10:
            break

    return recommendations if recommendations else {"message": "No recommendations found."}

@app.post("/chat")
def chat_endpoint(user_query: UserQuery):
    """
    Chat endpoint to process user input and return a bot response.
    """
    query = user_query.query
    bot_response = f"Bot Response to: {query}"
    return {"response": bot_response}

@app.post("/recommend")
def recommend_movies(recommendation_query: RecommendationQuery):
    """
    Recommend movies based on genre or actor extracted from user input.
    """
    user_input = recommendation_query.user_input
    genre, actor = extract_entities(user_input)
    
    if genre or actor:
        recommendations = fetch_movie_recommendations(genre, actor)
        
        # Ensure each movie has an overview (handle missing overview)
        for movie in recommendations:
            if not movie.get("overview"):
                movie["overview"] = "No overview available."  # Default value for missing overview

        return {"recommendations": recommendations}
    
    return {"message": "No genre or actor found in input."}

# Example to test locally (if needed)
if __name__ == "__main__":
    search_term = input("Enter a search term (genre or actor): ")
    movies = fetch_detailed_movie_data(search_term, max_movies=5)
    print(f"Movie Recommendations for '{search_term}':")
    for movie in movies:
        print(movie)
    
    genre = input("\nEnter a genre for recommendations: ")
    recommendations = fetch_movie_recommendations(genre=genre)
    print("\nDetailed Recommendations:")
    for rec in recommendations:
        print(rec)
