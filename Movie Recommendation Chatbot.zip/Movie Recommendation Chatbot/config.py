# config.py

OMDB_API_KEY = "f3909ea2"
OMDB_API_URL = "http://www.omdbapi.com/"
